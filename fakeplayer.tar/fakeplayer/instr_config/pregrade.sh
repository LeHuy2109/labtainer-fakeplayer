#!/bin/sh
# Standard Labtainers instructor-side preprocessing hook.
exec python3 "$(dirname "$0")/verify.py" "$1" "$2"
