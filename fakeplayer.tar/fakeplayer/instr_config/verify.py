#!/usr/bin/env python3
"""Validate collected static evidence; never execute student files or the APK.
Only the selected run contributes. Output is consumed by native LINE_COUNT/value.
All reference data remain in instr_config, outside the analyzer image.
"""
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import sys

base = Path(sys.argv[1]) / sys.argv[2]
reference = json.loads((Path(__file__).parent / 'reference.json').read_text())
weights = [10, 10, 15, 20, 25, 20]
out = base / '.local/result/fakeplayer-grade'
# Never trust student-supplied grading products or symlinks.
if out.is_symlink():
    out.unlink()
out.mkdir(parents=True, exist_ok=True)

def safe_read(path):
    path = Path(path)
    if any(p.is_symlink() for p in [path] + list(path.parents)):
        raise ValueError('Symlink in evidence')
    if not path.is_file() or path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError('Missing/oversized evidence')
    return path.read_bytes()

def text(path):
    return safe_read(path).decode('utf-8')

def digest(path):
    return hashlib.sha256(safe_read(path)).hexdigest()

def kv(path):
    answer = {}
    for line in text(path).splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        k, v = line.split('=', 1)
        if k.strip() in answer:
            raise ValueError('Duplicate answer')
        answer[k.strip()] = v.strip()
    return answer

scores = [0] * 6
reason = []
try:
    runs = base / 'Documents/fakeplayer-runs'
    run_id = text(runs / 'current-run.txt').strip()
    if not re.fullmatch(r'fakeplayer-[A-Za-z0-9_-]+', run_id):
        raise ValueError('Invalid run ID')
    run = runs / run_id
    if text(run / 'run-id.txt').strip() != run_id:
        raise ValueError('Run ID mismatch')
    ident = run / 'identity'
    identity_ok = (text(ident/'sha256.txt').split()[0] == reference['apk_sha256']
        and text(ident/'md5.txt').split()[0] == reference['apk_md5']
        and text(ident/'size.txt').strip() == '12867'
        and re.search(r'PornoPlayer\.apk: OK\s*$', text(ident/'hash-check.txt')) is not None
        and ('Zip archive' in text(ident/'file-type.txt') or 'Android package' in text(ident/'file-type.txt') or 'Java archive data (JAR)' in text(ident/'file-type.txt')))
    if not identity_ok:
        raise ValueError('Sample identity mismatch')
    for n, weight in enumerate(weights, 1):
        try:
            expected = reference['tasks'][str(n)]
            for rel, sha in expected['files'].items():
                if digest(run / rel) != sha:
                    raise ValueError('Evidence differs: ' + rel)
            for rel in expected.get('nonempty', []):
                if not text(run / rel).strip():
                    raise ValueError('Empty evidence: ' + rel)
            if 'answers' in expected:
                if kv(run / ('answers/task%d.txt' % n)) != expected['answers']:
                    raise ValueError('Review answers/task%d.txt' % n)
            if n == 5:
                rows = list(csv.reader(io.StringIO(text(run/'answers/task5.tsv')), delimiter='\t'))
                if rows != expected['rows']:
                    raise ValueError('Review the four call parameters and their class/method')
            scores[n-1] = weight
            reason.append('Task %d: verified' % n)
        except (ValueError, OSError, UnicodeError, IndexError) as e:
            reason.append('Task %d: %s' % (n, e))
except (ValueError, OSError, UnicodeError, IndexError) as e:
    reason.append('No valid selected run: %s' % e)

for name, value in list(zip(['task%d' % i for i in range(1,7)], scores)) + [('total', sum(scores))]:
    target = out / (name + '.txt')
    if target.is_symlink(): target.unlink()
    target.write_text('verified\n' * value)
(out/'feedback.txt').write_text('\n'.join(reason) + '\n')
